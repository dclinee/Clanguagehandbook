//charconl.c
#include <stdio.h>
int main(void)
{
  printf("%c %c %c\n", 65, 127 ,255);

  return 0;
}
